/* ============================================================
 * SwipeFlow Desktop —— 预加载桥接层
 * 仅暴露必要的桌面能力，渲染进程无法直接访问 Node / Electron 内部对象。
 * 页面通过 window.desktopAPI 检测桌面环境并做适配。
 * ============================================================ */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('desktopAPI', {
  isDesktop: true,
  info: () => ipcRenderer.invoke('desktop:info'),
  openPath: (target) => ipcRenderer.invoke('desktop:open-path', target),
  quit: () => ipcRenderer.invoke('desktop:quit')
});
