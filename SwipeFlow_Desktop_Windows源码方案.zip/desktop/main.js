/* ============================================================
 * SwipeFlow Desktop —— Electron 主进程（Windows 原生底层适配）
 * 职责：窗口生命周期、单实例、原生菜单/快捷键、下载管理、
 *       安全策略、离线资源加载、数据目录暴露。
 * ============================================================ */
const { app, BrowserWindow, shell, Menu, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');

const APP_NAME = 'SwipeFlow';
const isWin = process.platform === 'win32';

/* ---------- 单实例锁：重复启动聚焦已有窗口，避免数据多写 ---------- */
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  let mainWindow = null;

  /* ---------- 数据目录：localStorage / 收藏 / 题库进度均落在这里 ---------- */
  function ensureDataDir() {
    const dir = path.join(app.getPath('userData'), 'downloads');
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) {}
    return dir;
  }

  /* ---------- 创建主窗口 ---------- */
  function createWindow() {
    mainWindow = new BrowserWindow({
      width: 1360,
      height: 860,
      minWidth: 860,
      minHeight: 560,
      show: false,
      center: true,
      title: APP_NAME,
      backgroundColor: '#F3F3F3',
      icon: isWin ? path.join(__dirname, 'build', 'icon.ico')
                  : path.join(__dirname, 'app', 'icon.png'),
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
        nodeIntegration: false,       // 渲染层禁用 Node，保持页面为纯 Web 安全模型
        contextIsolation: true,       // 隔离上下文，桌面 API 由 preload 白名单暴露
        sandbox: true,                // 启用 Chromium 沙箱
        spellcheck: false,
        webviewTag: false,
        webSecurity: true,
        backgroundThrottling: false   // 后台不节流，刷题计时/动画稳定
      }
    });

    // 去掉原生菜单栏，贴近 Win11 应用观感
    Menu.setApplicationMenu(null);

    mainWindow.loadFile(path.join(__dirname, 'app', 'index.html'));

    mainWindow.once('ready-to-show', () => {
      mainWindow.show();
      // Win 下刷新任务栏图标，避免通用 Electron 图标
      if (isWin && mainWindow.setOverlayIcon) {
        try { mainWindow.setOverlayIcon(null, ''); } catch (e) {}
      }
    });

    mainWindow.on('closed', () => { mainWindow = null; });

    // 外链走系统浏览器，不在应用内打开
    mainWindow.webContents.setWindowOpenHandler(({ url }) => {
      if (/^https?:\/\//.test(url)) shell.openExternal(url);
      return { action: 'deny' };
    });

    // 桌面端文件下载：直接保存到 userData/downloads，不弹系统保存框
    mainWindow.webContents.session.on('will-download', (event, item) => {
      const dir = ensureDataDir();
      const name = item.getFilename() || `download-${Date.now()}.json`;
      item.setSavePath(path.join(dir, name));
    });
  }

  /* ---------- 原生 IPC：供页面调用的安全能力 ---------- */
  ipcMain.handle('desktop:info', () => ({
    platform: process.platform,
    version: app.getVersion(),
    electron: process.versions.electron,
    dataPath: app.getPath('userData'),
    downloadPath: ensureDataDir()
  }));

  ipcMain.handle('desktop:open-path', async (_, target) => {
    const dir = target === 'downloads' ? ensureDataDir()
              : target === 'data' ? app.getPath('userData') : null;
    if (!dir) return { ok: false };
    const err = await shell.openPath(dir);
    return { ok: !err, error: err };
  });

  ipcMain.handle('desktop:quit', () => app.quit());

  /* ---------- 应用生命周期 ---------- */
  app.whenReady().then(createWindow);

  app.on('window-all-closed', () => {
    // Windows/Linux：关闭窗口即退出；macOS 保留常规行为
    if (!isWin && process.platform !== 'darwin') app.quit();
    else if (isWin) app.quit();
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });

  // 禁用证书错误忽略等不安全设置（保持默认安全）
}
