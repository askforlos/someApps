/* ============================================================
 * SwipeFlow Desktop —— 页面侧桌面适配（非侵入增强）
 * 以独立脚本注入，不改动原刷题/收藏/题库核心逻辑。
 * 仅在 Electron 环境（window.desktopAPI 存在）时生效。
 * ================================================ */
(function () {
  if (!window.desktopAPI || !window.desktopAPI.isDesktop) return;

  const ICON_FOLDER = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>';

  // 每条规则：命中 from 且【尚未包含】 guard 时才替换。
  // guard 是关键：新文本以 from 为前缀，若不加 guard，下一轮替换会再次命中 from 并无限追加，
  // 每次写 textContent 又触发 MutationObserver，形成死循环导致「我的」等含 .hint 页面卡死。
  const REPLACEMENTS = [
    {
      from:  '数据保存在本机，卸载 App 会一并清除；可在「我的」导出备份。',
      to:    '数据保存在本机用户目录，可在「我的」打开数据目录备份；卸载程序不会删除数据。',
      guard: '本机用户目录'
    },
    {
      from:  '本地离线 · 无账号 · 无网络',
      to:    'Windows 桌面版 · 本地离线 · 无账号',
      guard: 'Windows 桌面版'
    },
    {
      from:  '内置题库来自个人整理，答案仅供参考；导入题库请使用固定模板。',
      to:    '内置题库来自个人整理，答案仅供参考；导入题库请使用固定模板。数据存放在用户目录，换机请导出备份。',
      guard: '数据存放在用户目录'
    }
  ];

  // 在「我的」管理列表末尾插入桌面专属入口（幂等：已存在则跳过）
  function injectDesktopEntries() {
    const app = document.getElementById('app');
    if (!app || !document.querySelector('#app .sec')) return;
    const sections = app.querySelectorAll('.sec');
    const manage = [...sections].find(s => s.querySelector('h2') && s.querySelector('h2').textContent === '管理');
    if (!manage) return;
    const list = manage.nextElementSibling;
    if (!list || !list.classList.contains('list') || list.querySelector('[data-openpath]')) return;

    const btn = document.createElement('button');
    btn.className = 'li';
    btn.setAttribute('data-openpath', 'data');
    btn.innerHTML = '<div class="ic">' + ICON_FOLDER + '</div>' +
      '<div class="grow"><div class="t">打开数据目录</div>' +
      '<div class="v">备份 / 管理本地题库与做题记录</div></div>' +
      '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m9 5 7 7-7 7"/></svg>';
    list.appendChild(btn);
  }

  // 只在文本真正变化时写 textContent：命中 from、未含 guard、且结果与原值不同。
  function adaptHints() {
    document.querySelectorAll('#app .hint').forEach(el => {
      const oldText = el.textContent || '';
      let next = oldText;
      for (const rule of REPLACEMENTS) {
        if (next.indexOf(rule.from) !== -1 && next.indexOf(rule.guard) === -1) {
          next = next.split(rule.from).join(rule.to);
        }
      }
      if (next !== oldText) el.textContent = next;
    });
  }

  // 桌面版键盘提示：统一为固定文案，已是该文案则不写。
  const SWIPE_FALLBACK = '用 ← → 键切题 · Esc 返回';
  function adaptSwipeHints() {
    document.querySelectorAll('.swipehint').forEach(el => {
      const oldText = el.textContent || '';
      let next;
      if (/切题|Esc|滑动|边缘/.test(oldText)) {
        next = SWIPE_FALLBACK;
      } else {
        return; // 其他提示文案不改动
      }
      if (next !== oldText) el.textContent = next;
    });
  }

  // 重入锁 + 「只在变化时写」双保险，确保 MutationObserver 循环一次即稳定。
  let applying = false;
  function applyDesktopEnhancements() {
    if (applying) return;
    applying = true;
    try {
      injectDesktopEntries();
      adaptHints();
      adaptSwipeHints();
    } finally {
      applying = false;
    }
  }

  // 事件：打开数据目录
  document.addEventListener('click', async (e) => {
    const t = e.target.closest && e.target.closest('[data-openpath]');
    if (!t) return;
    try {
      const r = await window.desktopAPI.openPath(t.getAttribute('data-openpath'));
      if (r && r.ok === false) {
        const toast = document.getElementById('toast');
        if (toast) { toast.textContent = '打开失败：' + (r.error || '未知错误'); toast.classList.add('on'); setTimeout(() => toast.classList.remove('on'), 1800); }
      }
    } catch (err) { /* 桌面 API 不可用时静默 */ }
  });

  // SPA 每次重绘后重新注入入口与提示
  const app = document.getElementById('app') || document.body;
  const observer = new MutationObserver(() => { applyDesktopEnhancements(); });
  observer.observe(app, { childList: true, subtree: true });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', applyDesktopEnhancements);
  else applyDesktopEnhancements();
})();
