# SwipeFlow Desktop · Windows 桌面打包方案

基于 Electron 的 Windows 原生桌面封装，将原 HBuilderX 单页题库工程从底层适配为 `.exe` 应用。

## 目录结构

```
desktop/
├── main.js              # Electron 主进程：窗口/单实例/菜单/下载/安全策略
├── preload.js           # 预加载桥接：白名单暴露桌面 API
├── package.json         # 依赖与 electron-builder 打包配置
├── build/
│   └── icon.ico         # Windows 多尺寸图标（16~256px）
├── app/                 # 原 HBuilderX 工程完整副本 + desktop-bridge.js
│   ├── index.html
│   ├── desktop-bridge.js
│   └── ...
└── dist/                # 构建产物（打包后生成）
```

## 构建（Windows / Linux / macOS 均可交叉构建）

```bash
cd desktop
npm install
npm run dist          # 同时生成 NSIS 安装包 + 便携版
```

产物位于 `dist/`：

| 文件 | 说明 |
|---|---|
| `SwipeFlow-2.8.0-x64.exe` | NSIS 安装程序，可自定义安装目录、创建桌面/开始菜单快捷方式 |
| `SwipeFlow-2.8.0-便携版.exe` | 免安装便携版，双击即运行 |

> Linux 交叉构建 Windows 包时建议设置国内镜像加速：
> ```bash
> export ELECTRON_MIRROR=https://npmmirror.com/mirrors/electron/
> export ELECTRON_BUILDER_BINARIES_MIRROR=https://npmmirror.com/mirrors/electron-builder-binaries/
> ```

## 本地开发调试

```bash
npm install
npm start
```

## 底层适配说明

1. **单实例锁**：重复启动自动聚焦已打开窗口，避免多进程同时写 localStorage 造成数据错乱。
2. **安全模型**：渲染层 `nodeIntegration: false` + `contextIsolation: true` + `sandbox: true`，桌面能力仅通过 preload 白名单暴露。
3. **数据目录**：应用数据保存在 `%APPDATA%/SwipeFlow`（Windows），题库进度/收藏/设置随 localStorage 持久化；导出文件落在 `downloads/` 子目录。**卸载程序不会删除该目录**。
4. **桌面增强**：「我的 → 打开数据目录」可一键定位备份位置；提示文案按桌面版调整。
5. **下载管理**：导出题库直接保存到数据目录，不弹系统保存框，避免下载中断。
6. **外链处理**：应用内外部链接交由系统浏览器打开。
7. **无 plus API 依赖**：原 HBuilderX 的 `window.plus` 判断在 Electron 中自然跳过，无副作用；返回/切题统一由页面内按钮与键盘 `Esc`、`← →` 处理。
8. **窗口适配**：初始 1360×860，最小 860×560，适配 PC 宽屏多列布局与 Win11 简洁视觉。

## 当前版本说明（v2.8 · 干净重建版）

本版本以原始 HBuilderX v2.7「简洁流畅版」为基底**推翻重建**，仅保留原生全部功能并做桌面化改造：

- **题库**：7 个学科（妇产/内科/外科/儿科/口腔/眼科/耳鼻喉）全部内嵌于 `index.html`，共 6202 题；已移除独立的 `眼科学题库_第十版_合并.json` 等数据文件（配置类 `manifest.json` 保留）。
- **视觉**：全量 Win11 Fluent 风格（Segoe UI 字体、系统蓝强调、8~12px 圆角、纯白卡片、亚克力侧栏），无渐变/几何装饰。
- **交互**：彻底移除手机端触摸滑动手势，改为 PC 键鼠操作 —— `← →` 切题、`Esc` 返回/关闭、鼠标点击。
- **动画**：按压反馈采用 Web Animations API 实现的**阻尼衰减弹簧**（按下快速形变不弹 → 松手多次过冲后自然回稳），替代单一 `cubic-bezier` 的生硬回弹；页面转场、切题轨道改用平滑无过冲曲线，避免晃动；展开卡片与弹层保留极轻微末端回弹。`prefers-reduced-motion` 下自动降级。
- **布局**：宽屏（≥900px）为左侧竖向导航 + 自适应多列卡片网格，展开卡片放大至 900×720，弹层居中为模态对话框；手机窄屏自动回退为底部 Dock + 双列布局。

## 更新应用内容

修改 `app/` 下的 `index.html` 或资源后，重新执行 `npm run dist` 即可。版本号在 `package.json` 的 `version` 字段调整。
